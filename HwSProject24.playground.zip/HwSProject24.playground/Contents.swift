//: Playground - noun: a place where people can play

import UIKit

//extension Int {
//    func plusOne() -> Int {
//        return self + 1
//    }
//}

//extension Int {
//    mutating func plusOne(){
//        self += 1
//    }
//}

//var myInt = 0
//let otherInt = 0
//myInt.plusOne()

//constants are not mutable
//otherInt.plusOne()

//literals are not mutable
//5.plusOne()

//plus one doesnt alter original value
//myInt

//-------------------------------------------------------------------------------
extension BinaryInteger {
    func squared() -> Self {
        return self * self
    }
}

let i: Int = 8
print(i.squared())

let j: UInt64 = 8
print(i.squared())
//-------------------------------------------------------------------------------

extension String {
    mutating func trim() {
        self = trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
    }
}

var myString =     "Hello, World"
myString.trim()











